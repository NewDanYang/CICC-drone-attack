#!/usr/bin/env bash
set -euo pipefail
root=/home/ubuntu/multimodal_3_4_offline_20261026
test ! -e /tmp/tcei_formal_trial.lock
test ! -e "$root/probe_results"
apps="$(nvidia-smi --query-compute-apps=pid,process_name,used_gpu_memory --format=csv,noheader)"
printf '%s\n' "$apps" > "$root/gpu_before.txt"
test -z "$apps"
tar -xzf "$root/input.tar.gz" -C "$root/input"
snapshot() {
  md5sum /home/ubuntu/model/mission_once.py \
    /home/ubuntu/catkin_ws/src/mission_pkg/src/bt_ros.cpp \
    /home/ubuntu/catkin_ws/devel/lib/mission_pkg/bt_ros \
    /home/ubuntu/catkin_ws/src/mission_pkg/launch/llm_mission.launch \
    /home/ubuntu/catkin_ws/src/mission_pkg/include/base/drone_action_node.h \
    /home/ubuntu/catkin_ws/src/mission_pkg/src/nodes/action/visual_servo.cpp \
    /home/ubuntu/catkin_ws/src/mission_pkg/include/nodes/action/visual_servo.h \
    /home/ubuntu/catkin_ws/src/mission_pkg/src/nodes/action/goto.cpp \
    /home/ubuntu/catkin_ws/src/mission_pkg/include/nodes/action/goto.h \
    /home/ubuntu/catkin_ws/src/mission_pkg/src/mavros_cnt.cpp \
    /home/ubuntu/catkin_ws/src/sensor_pkg/Config.json
}
snapshot > "$root/deployment_before.md5"
set +e
timeout 900 /opt/conda/envs/demo/bin/python3 -u "$root/probe_two_step.py" \
  --data "$root/input" --reference "$root/evaluate_3_1_v2.py" --output "$root/probe_results"
rc=$?
set -e
printf '%s\n' "$rc" > "$root/probe_exit_code"
snapshot > "$root/deployment_after.md5"
cmp "$root/deployment_before.md5" "$root/deployment_after.md5"
echo "DEPLOYMENT_UNCHANGED=1"
echo "PROBE_EXIT_CODE=$rc"
