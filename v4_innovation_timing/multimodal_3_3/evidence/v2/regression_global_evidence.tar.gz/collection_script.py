"""Read-only closing receipt; refuse to collect before the original 18 rows finish."""
import csv
from datetime import datetime, timezone
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

ROOT=Path('/home/ubuntu/tcei_baseline_tools/results/multimodal_v2_regression_20261026')
PACKAGE=Path('/home/ubuntu/multimodal_v2')
BACKUP=Path('/home/ubuntu/multimodal_v2_backup_20261026T0009')
OUT=Path('/home/ubuntu/multimodal_v2_exports/final')
receipts=[json.loads(p.read_text()) for p in sorted(ROOT.glob('*/driver_complete.json'))]
assert len(receipts)==18 and {r['index'] for r in receipts}==set(range(1,19))
progress=[json.loads(s) for s in (ROOT/'progress.jsonl').read_text().splitlines()]
assert progress[-1]['phase']=='regression_complete'
assert 'environment_started=1' in (ROOT/'final_rollback.log').read_text()
assert not Path('/tmp/tcei_formal_trial.lock').exists()
deployment=json.loads(subprocess.check_output(['/usr/bin/python3',str(PACKAGE/'patches/deploy_v2.py'),'status',str(BACKUP)],text=True))
assert deployment['mode']=='baseline'
ws=Path('/home/ubuntu/catkin_ws')
guards=dict(deployment['guards'])
guards.update({
    str(ws/'src/mission_pkg/src/nodes/action/goto.cpp'):'f557ace5bbf2ee7975b7335a738ffcf9',
    str(ws/'src/mission_pkg/include/nodes/action/goto.h'):'ee765e08024ea28cb1b8d32104a272d3',
    str(ws/'src/mission_pkg/src/mavros_cnt.cpp'):'edcd9397074f44c6028c8dca02902920',
    str(ws/'src/sensor_pkg/Config.json'):'380f5f1f78000cdde9c8e116f7583e19',
})
actual={p:hashlib.md5(Path(p).read_bytes()).hexdigest() for p in guards}
assert actual==guards
binary=ws/'devel/lib/mission_pkg/bt_ros'
binary_bytes=binary.read_bytes()
assert b'<TargetTracker object_name' in binary_bytes
assert b'<MultimodalTargetTracker' not in binary_bytes
removed=[Path('/home/ubuntu/model/fm9g_perception'),ws/'devel/lib/multimodal_target_tracker.so',
    ws/'src/mission_pkg/src/nodes/perception/multimodal_target_tracker.cpp',
    ws/'src/mission_pkg/include/nodes/perception/multimodal_target_tracker.h']
assert not any(p.exists() for p in removed)
def ros(command):
    return subprocess.check_output(['bash','-c','source /home/ubuntu/catkin_ws/devel/setup.bash && '+command],text=True)
state=ros('timeout 10 rostopic echo -n 1 /mavros/state')
assert 'armed: False' in state
parameters={name:ros('rosparam get '+name).strip() for name in
    ('/ego_planner_node/manager/max_vel','/ego_planner_node/optimization/max_vel')}
loaded=[]
for proc in Path('/proc').iterdir():
    if not proc.name.isdecimal():continue
    try:
        if (proc/'comm').read_text().strip()!='bt_ros':continue
        executable=(proc/'exe').read_bytes()
        loaded.append(dict(pid=int(proc.name),executable_md5=hashlib.md5(executable).hexdigest(),
            matches_disk=executable==binary_bytes,
            multimodal_plugin_loaded='multimodal_target_tracker.so' in (proc/'maps').read_text()))
    except (FileNotFoundError,PermissionError,ProcessLookupError):continue
assert loaded and all(r['matches_disk'] and not r['multimodal_plugin_loaded'] for r in loaded)
OUT.mkdir(exist_ok=True)
closing=dict(collected_at=datetime.now(timezone.utc).isoformat(),completed_original_runs=18,
    deployment=deployment,protected_md5=actual,expected_protected_md5=guards,
    candidate_paths_absent={str(p):not p.exists() for p in removed},
    baseline_binary_tag_present=True,candidate_binary_tag_present=False,loaded_bt=loaded,
    mavros_state=state,formal_trial_lock_present=False,planner_params=parameters,
    environment_started_marker=True,final_rollback_progress=progress[-2:])
(OUT/'final_state.json').write_text(json.dumps(closing,indent=2)+'\n')
with (OUT/'native_18_runs.csv').open('w',newline='') as stream:
    writer=csv.DictWriter(stream,fieldnames=list(receipts[0]['native_row']))
    writer.writeheader();writer.writerows(r['native_row'] for r in receipts)
files=[(p,'regression/'+p.name) for p in sorted(ROOT.iterdir()) if p.is_file()]
files += [(p,p.name) for p in sorted(OUT.iterdir()) if p.name in ('final_state.json','native_18_runs.csv')]
files.append((Path(__file__),'collection_script.py'))
for name in ('mm_v2_regression_active.log','mm_v2_regression_resumed.log','mm_v2_resume_bootstrap.log',
             'mm_resume_bootstrap.sh','mm_resume_driver.sh'):
    path=Path('/tmp')/name
    if path.is_file():files.append((path,'recovery/'+name))
for name in ('run_regression_v2.py','resume_after_reboot_v2.py','calibrate_scene_evaluation_v2.py','analyze_regression_v2.py'):
    files.append((PACKAGE/'tools'/name,'executed_tools/'+name))
positive_rgb=[]
for path in sorted(ROOT.glob('*/driver_complete.json')):
    session=path.parent;row=json.loads(path.read_text())
    mapping=json.loads((session/'evaluation_mapping.json').read_text())
    if mapping.get('complete') and row['color'] not in mapping.get('actor_to_color',{}).values():
        pictures=sorted((session/'audit/frames').glob('*.jpg'))
        files.extend((p,'target_deletion_rgb/'+session.name+'/frames/'+p.name) for p in pictures)
        positive_rgb.append(dict(session=session.name,full_rgb_frames=len(pictures)))
(OUT/'positive_rgb_index.json').write_text(json.dumps(positive_rgb,indent=2)+'\n')
files.append((OUT/'positive_rgb_index.json','positive_rgb_index.json'))
destination=OUT/'regression_global_evidence.tar.gz'
manifest=[]
with tarfile.open(destination,'w:gz') as archive:
    for path,name in files:
        data=path.read_bytes();info=tarfile.TarInfo(name);info.size=len(data)
        archive.addfile(info,io.BytesIO(data))
        manifest.append(dict(path=name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
    data=(json.dumps(manifest,indent=2)+'\n').encode();info=tarfile.TarInfo('MANIFEST.json');info.size=len(data)
    archive.addfile(info,io.BytesIO(data))
receipt=dict(archive=str(destination),bytes=destination.stat().st_size,
    sha256=hashlib.sha256(destination.read_bytes()).hexdigest(),files=len(files))
(OUT/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(closing,indent=2));print(json.dumps(receipt,indent=2))
