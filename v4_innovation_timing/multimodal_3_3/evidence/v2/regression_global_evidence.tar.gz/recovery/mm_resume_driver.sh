#!/usr/bin/env bash
set -euo pipefail
set +u
source /home/ubuntu/catkin_ws/devel/setup.bash
set -u
export DISPLAY=:20 XAUTHORITY=/home/ubuntu/.Xauthority
exec /usr/bin/python3 -u /home/ubuntu/multimodal_v2/tools/resume_after_reboot_v2.py
