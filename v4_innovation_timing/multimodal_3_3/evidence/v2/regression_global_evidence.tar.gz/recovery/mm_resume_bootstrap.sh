#!/usr/bin/env bash
set -euo pipefail
batch=/home/ubuntu/tcei_baseline_tools/results/multimodal_v2_regression_20261026
test ! -e /tmp/tcei_formal_trial.lock
test ! -d "$batch/06_r1_blue_candidate"
test ! -e "$batch/06_switch.interrupted_20261026T1806.log"
cp -p "$batch/06_switch.log" "$batch/06_switch.interrupted_20261026T1806.log"
bash /home/ubuntu/multimodal_v2/patches/build_v2.sh candidate /home/ubuntu/multimodal_v2_backup_20261026T0009
export DISPLAY=:20 XAUTHORITY=/home/ubuntu/.Xauthority
exec bash /home/ubuntu/tcei_baseline_tools/start_sim_environment.sh
