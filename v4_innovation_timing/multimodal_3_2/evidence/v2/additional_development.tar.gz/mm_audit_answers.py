import json,sys
from pathlib import Path
from collections import Counter
sys.path.insert(0,'/home/ubuntu/multimodal_v2')
from v2.localizer import parse_tile
root=Path('/home/ubuntu/tcei_baseline_tools/results')
for session in sorted(root.glob('multimodal_v2_demo*20261026')):
    kinds=Counter();bad=Counter();labels=Counter();calls=0
    for path in (session/'model').glob('*/audit.jsonl'):
        for row in map(json.loads,path.read_text().splitlines()):
            if row['kind']!='model_call':continue
            calls+=1
            for answer in row['answers']:
                try:labels[str(parse_tile(answer))]+=1
                except ValueError:bad[answer]+=1
    print(session.name,'calls',calls,'valid_labels',dict(labels),'malformed',sum(bad.values()),'examples',bad.most_common(12))
