import sys,json,time,hashlib
from pathlib import Path
from PIL import Image
root=Path('/home/ubuntu/tcei_baseline_tools/results')
outroot=Path('/tmp/mm_color_question_probe');outroot.mkdir(exist_ok=False)
cases=[]
for name in ('multimodal_v2_demo3_red_20261026','multimodal_v2_demo4_red_20261026','multimodal_v2_demo_purple_20261026'):
 selected=0
 for log in (root/name/'model').glob('*/audit.jsonl'):
  rows=list(map(json.loads,log.read_text().splitlines()));sources={r['decision']:r for r in rows if r['kind']=='model_source'}
  for r in rows:
   if r['kind']!='overlapping_tiles' or selected>=6:continue
   candidates=[i for i,a in enumerate(r['answers']) if '气球' in a and ('有一个' in a or '有一只' in a) and not any(c in a for c in ('红色','紫色','蓝色'))]
   if not candidates:continue
   i=candidates[0];source=sources[r['decision']];im=Image.open(log.parent/source['image']).convert('RGB').crop(r['boxes'][i])
   file=outroot/f'crop_{len(cases):02d}.png';im.save(file)
   cases.append(dict(image=str(file),source=str(log.parent/source['image']),box=r['boxes'][i],old_answer=r['answers'][i],collection=name))
   selected+=1
for name in ('red','purple','blue','blue_wall'):
 cases.append(dict(image='/tmp/mm_v2_probe/'+name+'.jpg',collection='development_full',source=name))
(outroot/'cases.json').write_text(json.dumps(cases,ensure_ascii=False,indent=2))
import torch
torch.set_num_threads(2);torch.set_num_interop_threads(1)
from transformers import AutoModel,AutoTokenizer,AutoProcessor
path='/home/ubuntu/model/FM9G4B-V'
model=AutoModel.from_pretrained(path,trust_remote_code=True,local_files_only=True,attn_implementation='sdpa',torch_dtype=torch.bfloat16).eval().cuda()
tokenizer=AutoTokenizer.from_pretrained(path,trust_remote_code=True,local_files_only=True)
processor=AutoProcessor.from_pretrained(path,trust_remote_code=True,local_files_only=True)
prompts={
 'color_word':'图中气球是什么颜色？只回答一个英文单词：red、purple、blue 或 none。无气球时回答none。小车、墙壁、天空不是气球。',
 'color_list':'识别图中实际可见气球的颜色，不把小车、墙壁或天空当气球。只输出一个JSON字符串数组，数组元素只能是red、blue或purple，可有多个颜色；没有气球输出[]。不要解释。'}
with (outroot/'results.jsonl').open('w') as out:
 for mode,prompt in prompts.items():
  for offset in range(0,len(cases),16):
   part=cases[offset:offset+16];msgs=[[{'role':'user','content':[Image.open(r['image']).convert('RGB'),prompt]}] for r in part]
   start=time.monotonic()
   with torch.inference_mode():answers=model.chat(image=None,msgs=msgs,tokenizer=tokenizer,processor=processor,sampling=False,stream=False,num_beams=1,max_new_tokens=24 if mode=='color_list' else 12,max_slice_nums=1)
   elapsed=time.monotonic()-start
   for case,answer in zip(part,answers):
    row=dict(case,mode=mode,prompt=prompt,answer=answer,batch_size=len(part),batch_latency_s=elapsed,sha256=hashlib.sha256(Path(case['image']).read_bytes()).hexdigest())
    out.write(json.dumps(row,ensure_ascii=False)+'\n');print(json.dumps(row,ensure_ascii=False),flush=True)
print('COLOR_QUESTION_DONE',flush=True)
