import inspect,json,sys
from pathlib import Path
sys.path.insert(0,'/home/ubuntu/multimodal_v2')
import cv2,numpy as np
cv2.setNumThreads(2)
from v2.refinement import refine
source=inspect.getsource(refine)
source=source.replace('x1-rx1-8','x1-rx1-max(8,round((x2-x1)*.25))').replace('y1-ry1-8','y1-ry1-max(8,round((y2-y1)*.25))')
source=source.replace('x2-rx1+8','x2-rx1+max(8,round((x2-x1)*.25))').replace('y2-ry1+8','y2-ry1+max(8,round((y2-y1)*.25))')
exec(source,globals())
rows=list(map(json.loads,Path('/tmp/mm_overlap_probe.jsonl').read_text().splitlines()))
root=Path('/home/ubuntu/tcei_baseline_tools/results/multimodal_v2_demo3_red_20261026/model/20261025T170902_eedaf4')
audit=list(map(json.loads,(root/'audit.jsonl').read_text().splitlines()))
sources={r['decision']:r for r in audit if r['kind']=='model_source'}
for r in audit:
 if r['kind']=='decision' and r.get('model_box'):
  rows.append(dict(image=str(root/sources[r['decision']]['image']),color=r['color'],model_box=r['model_box'],bbox=r['bbox']))
with open('/tmp/mm_refine_context_background_probe.jsonl','w') as out:
 for row in rows:
    row['old_bbox']=row['bbox'];row['bbox']=refine(cv2.imread(row['image']),row['model_box'])
    out.write(json.dumps(row)+'\n');print(json.dumps({k:v for k,v in row.items() if k not in ('boxes','answers')}))
