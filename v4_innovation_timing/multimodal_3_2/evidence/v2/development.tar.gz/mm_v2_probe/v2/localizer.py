"""FM9G-only image localization by uniformly tiled semantic queries.

No detector, HSV threshold, contour proposal, world coordinate or flight command
is used here. All semantic observations come from the supplied model callable.
"""
import json
import math
import re
from PIL import Image, ImageDraw

COARSE_PROMPT = (
    '图片被白线分成9格，每格左上角写了编号1到9。请列出实际可见的气球颜色和气球中心所在格的编号。'
    '只输出JSON：{"balloons":[{"color":"red/blue/purple","cell":1}]}。'
    'color只能red、blue、purple之一，cell只能1到9。没有气球则输出{"balloons":[]}。不要解释。')
TILE_PROMPT = ('这张图片中有没有气球？如果有，只回复red balloon、purple balloon或blue balloon。'
               '如果没有气球，只回复no balloon。平坦的墙壁、天空和小车不是气球。不要解释。')
DETAIL_PROMPT = ('这是已经由你识别出的气球附近的局部细节图。'
                 '请判断里面是否有鲜艳红色、紫色或宝蓝色的色块，即使只是一小部分。'
                 '只回答red、purple、blue或none。灰蓝色墙壁、灰白地面、黑色小车、天空属于none。'
                 '不要要求局部色块保留完整的气球形状。不要解释。')
COLORS = {'red', 'purple', 'blue'}


def one_json(answer):
    text = str(answer).strip()
    # Preserve raw output in the audit log; permit prose around ONE complete
    # JSON object, never a guessed repair of missing or mismatched fields.
    decoder = json.JSONDecoder()
    decoded = []
    for match in re.finditer(r'\{', text):
        try:
            value, length = decoder.raw_decode(text[match.start():])
        except ValueError:
            continue
        if isinstance(value, dict) and 'balloons' in value:
            decoded.append(value)
    if len(decoded) != 1:
        raise ValueError('Expected one balloons JSON object')
    return decoded[0]


def parse_coarse(answer):
    obj = one_json(answer)
    if set(obj) != {'balloons'} or not isinstance(obj['balloons'], list):
        raise ValueError('Invalid coarse schema')
    rows = []
    for item in obj['balloons']:
        if not isinstance(item, dict) or set(item) != {'color', 'cell'}:
            raise ValueError('Invalid coarse record')
        if item['color'] not in COLORS or type(item['cell']) is not int or not 1 <= item['cell'] <= 9:
            raise ValueError('Invalid color/cell')
        rows.append(item)
    return rows


def parse_tile(answer):
    text = str(answer).strip().lower().strip('`\"\' .。\n')
    values = {'red balloon': 'red', 'purple balloon': 'purple', 'blue balloon': 'blue',
              'no balloon': None, '红色气球': 'red', '紫色气球': 'purple', '蓝色气球': 'blue',
              '无气球': None, '没有气球': None,
              'red':'red','purple':'purple','blue':'blue','none':None,
              '红色':'red','紫色':'purple','蓝色':'blue'}
    if text not in values:
        raise ValueError('Invalid semantic tile answer: '+repr(text))
    return values[text]


def clipped_box(box, size):
    width, height = size
    x1,y1,x2,y2 = box
    result = [max(0,int(math.floor(x1))), max(0,int(math.floor(y1))),
              min(width,int(math.ceil(x2))), min(height,int(math.ceil(y2)))]
    if result[0] >= result[2] or result[1] >= result[3]:
        raise ValueError('Empty ROI')
    return result


def expand(box, fraction, size):
    x1,y1,x2,y2=box
    dx,dy=(x2-x1)*fraction,(y2-y1)*fraction
    return clipped_box((x1-dx,y1-dy,x2+dx,y2+dy),size)


def nine_grid(image):
    result = image.copy()
    width,height=result.size
    draw=ImageDraw.Draw(result)
    for i in (1,2):
        draw.line((round(i*width/3),0,round(i*width/3),height-1),fill='white',width=2)
        draw.line((0,round(i*height/3),width-1,round(i*height/3)),fill='white',width=2)
    for row in range(3):
        for col in range(3):
            x,y=round(col*width/3)+4,round(row*height/3)+4
            draw.rectangle((x,y,x+22,y+22),fill='black')
            draw.text((x+7,y+4),str(row*3+col+1),fill='white')
    return result


def components(indices, grid=4):
    pending=set(indices)
    result=[]
    while pending:
        seed=pending.pop()
        group={seed}
        todo=[seed]
        while todo:
            index=todo.pop()
            row,col=divmod(index,grid)
            neighbors={r*grid+c for r in range(row-1,row+2) for c in range(col-1,col+2)
                       if 0<=r<grid and 0<=c<grid}
            added=neighbors & pending
            pending-=added
            group|=added
            todo.extend(added)
        result.append(group)
    return result


class TiledLocalizer:
    def __init__(self, infer, audit=lambda **kwargs: None):
        self.infer=infer
        self.audit=audit

    def locate(self, image, color, roi=None, levels=3):
        if color not in COLORS:
            raise ValueError('Invalid requested color')
        if roi is None:
            # Number-reading and direct coordinate regression both failed the
            # development probe. Scan ALL equally sized tiles, independently;
            # no predicted coarse location is trusted to hide image regions.
            roi=[0,0,*image.size]
        else:
            roi=clipped_box(roi,image.size)
        for level in range(levels):
            x1,y1,x2,y2=roi
            boxes=[]
            crops=[]
            for row in range(4):
                for col in range(4):
                    box=clipped_box([x1+col*(x2-x1)/4,y1+row*(y2-y1)/4,
                                     x1+(col+1)*(x2-x1)/4,y1+(row+1)*(y2-y1)/4],image.size)
                    boxes.append(box)
                    crops.append(image.crop(box))
            answers=self.infer(crops,TILE_PROMPT if level==0 else DETAIL_PROMPT)
            if len(answers)!=len(boxes):
                raise ValueError('Batch answer count mismatch')
            labels=[]
            for answer in answers:
                try: labels.append(parse_tile(answer))
                except ValueError: labels.append(None)
            groups=components(i for i,value in enumerate(labels) if value==color)
            self.audit(kind='tiles',level=level,roi=roi,boxes=boxes,answers=answers,labels=labels,
                       components=[sorted(g) for g in groups])
            if not groups:
                return None
            # This uses only model outputs. Prefer a coherent group; ties keep
            # the spatial prior selected by this SAME model at the coarse step.
            midx,midy=(x1+x2)/2,(y1+y2)/2
            def rank(group):
                cx=sum((boxes[i][0]+boxes[i][2])/2 for i in group)/len(group)
                cy=sum((boxes[i][1]+boxes[i][3])/2 for i in group)/len(group)
                return (-len(group),(cx-midx)**2+(cy-midy)**2)
            # Once the model has selected a local ROI, keep separated visible
            # pieces of the same balloon (e.g. specular highlights split the
            # semantic mask). No image/color heuristic fills these decisions.
            group=min(groups,key=rank) if level==0 else set().union(*groups)
            box=[min(boxes[i][0] for i in group),min(boxes[i][1] for i in group),
                 max(boxes[i][2] for i in group),max(boxes[i][3] for i in group)]
            if level+1==levels:
                return box
            roi=expand(box,0.25,image.size)
        return None
