import json
from pathlib import Path
import sys
sys.path.insert(0,'/tmp/mm_v2_probe')
import cv2
from v2.refinement import refine

for directory in ('localizer_detail','holdout'):
    for line in (Path('/tmp/mm_v2_probe')/directory/'results.jsonl').read_text(encoding='utf-8').splitlines():
        row=json.loads(line)
        source=cv2.imread(row['image'])
        result=refine(source,row['bbox'])
        row={k:v for k,v in row.items() if k!='evidence'}
        row.update(refined_bbox=result)
        print(json.dumps(row,ensure_ascii=False),flush=True)
