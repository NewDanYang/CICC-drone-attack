import json,sys
from pathlib import Path
sys.path.insert(0,'/home/ubuntu/multimodal_v2')
import cv2
from v2.localizer import TiledLocalizer
from v2.refinement import refine
from PIL import Image
cv2.setNumThreads(2)
inputs=[]
for folder in ('localizer_detail','holdout','localizer_union'):
    path=Path('/tmp/mm_v2_probe')/folder/'results.jsonl'
    if not path.exists():continue
    for row in map(json.loads,path.read_text().splitlines()):
        calls=[e['answers'] for e in row['evidence'] if e.get('kind')=='inference']
        inputs.append((row['image'],row['color'],folder,calls))
session=Path('/home/ubuntu/tcei_baseline_tools/results/multimodal_v2_demo2_red_20261026/model/20261025T164909_0ce18d')
rows=list(map(json.loads,(session/'audit.jsonl').read_text().splitlines()))
for source in (r for r in rows if r['kind']=='model_source'):
    calls=[r['answers'] for r in rows if r['kind']=='model_call' and r['decision']==source['decision']]
    inputs.append((str(session/source['image']),source['color'],'live_red2',calls))
with open('/tmp/mm_v2_cached_levels.jsonl','w') as out:
    for image,color,dataset,calls in inputs:
        im=Image.open(image).convert('RGB');bgr=cv2.imread(image)
        for levels in (1,2,3):
            answers=iter(calls)
            try:box=TiledLocalizer(lambda images,prompt:next(answers)).locate(im,color,levels=levels)
            except StopIteration:continue
            refined=refine(bgr,box)
            row=dict(image=image,color=color,dataset=dataset,levels=levels,model_box=box,bbox=refined)
            out.write(json.dumps(row)+'\n')
            if box:print(json.dumps(row))
