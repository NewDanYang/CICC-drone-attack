import json,sys,time
from pathlib import Path
sys.path.insert(0,'/home/ubuntu/multimodal_v2')
import torch
torch.set_num_threads(2);torch.set_num_interop_threads(1)
from PIL import Image
from transformers import AutoModel,AutoTokenizer,AutoProcessor
from v2.localizer import TILE_PROMPT,parse_tile,clipped_box,expand
path='/home/ubuntu/model/FM9G4B-V'
model=AutoModel.from_pretrained(path,trust_remote_code=True,local_files_only=True,attn_implementation='sdpa',torch_dtype=torch.bfloat16).eval().cuda()
tokenizer=AutoTokenizer.from_pretrained(path,trust_remote_code=True,local_files_only=True)
processor=AutoProcessor.from_pretrained(path,trust_remote_code=True,local_files_only=True)
rows=[r for r in map(json.loads,Path('/tmp/mm_v2_cached_levels.jsonl').read_text().splitlines()) if r['levels'] in (1,2) and r['bbox'] and r['dataset']!='localizer_union']
messages=[]
for r in rows:
    im=Image.open(r['image']).convert('RGB');x1,y1,x2,y2=r['bbox'];dx=(x2-x1)*.15;dy=(y2-y1)*.15
    center=clipped_box([x1+dx,y1+dy,x2-dx,y2-dy],im.size)
    for box in (expand(r['bbox'],.15,im.size),center):messages.append([{'role':'user','content':[im.crop(box),TILE_PROMPT]}])
answers=[]
for offset in range(0,len(messages),16):
    start=time.monotonic()
    with torch.inference_mode():result=model.chat(image=None,msgs=messages[offset:offset+16],tokenizer=tokenizer,processor=processor,sampling=False,stream=False,num_beams=1,max_new_tokens=12,max_slice_nums=1)
    print('batch',offset,len(result),time.monotonic()-start,flush=True);answers+=result
with open('/tmp/mm_fast_init_probe.jsonl','w') as out:
    for i,r in enumerate(rows):
        r.update(full_answer=answers[i*2],center_answer=answers[i*2+1])
        r['accept']=all(parse_tile(a)==r['color'] for a in answers[i*2:i*2+2])
        out.write(json.dumps(r)+'\n');print(json.dumps(r),flush=True)
