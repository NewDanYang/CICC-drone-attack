import inspect,json,sys
from pathlib import Path
sys.path.insert(0,'/home/ubuntu/multimodal_v2')
import cv2,numpy as np
cv2.setNumThreads(2)
from v2.refinement import refine
source=inspect.getsource(refine)
old='    if 2<=ax<cw-2 and 2<=ay<ch-2:\n        mask[ay-1:ay+2,ax-1:ax+2]=cv2.GC_FGD\n'
assert old in source
exec(source.replace(old,''),globals())
with open('/tmp/mm_refine_no_seed.jsonl','w') as out:
 for row in map(json.loads,Path('/tmp/mm_overlap_probe.jsonl').read_text().splitlines()):
    row['old_bbox']=row['bbox'];row['bbox']=refine(cv2.imread(row['image']),row['model_box'])
    out.write(json.dumps(row)+'\n');print(json.dumps({k:v for k,v in row.items() if k not in ('boxes','answers')}))
