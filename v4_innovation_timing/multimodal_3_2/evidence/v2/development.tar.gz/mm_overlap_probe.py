import sys,json,time
from pathlib import Path
sys.path.insert(0,'/home/ubuntu/multimodal_v2')
import torch
torch.set_num_threads(2);torch.set_num_interop_threads(1)
from PIL import Image
import cv2
cv2.setNumThreads(2)
from transformers import AutoModel,AutoTokenizer,AutoProcessor
from v2.localizer import TILE_PROMPT,parse_tile
from v2.refinement import refine
path='/home/ubuntu/model/FM9G4B-V'
model=AutoModel.from_pretrained(path,trust_remote_code=True,local_files_only=True,attn_implementation='sdpa',torch_dtype=torch.bfloat16).eval().cuda()
tokenizer=AutoTokenizer.from_pretrained(path,trust_remote_code=True,local_files_only=True)
processor=AutoProcessor.from_pretrained(path,trust_remote_code=True,local_files_only=True)
cases=[(str(Path('/tmp/mm_v2_probe')/(color+'.jpg')),color) for color in ('red','purple','blue')]
cases += [(str(Path('/tmp/mm_v2_probe')/(color+'_later.jpg')),color) for color in ('red','purple','blue')]
cases += [('/tmp/mm_v2_probe/blue_near.jpg','blue'),('/tmp/mm_v2_probe/blue_edge.jpg','blue'),('/tmp/mm_v2_probe/blue_wall.jpg','blue')]
root=Path('/home/ubuntu/tcei_baseline_tools/results/multimodal_v2_demo2_red_20261026/model/20261025T164909_0ce18d/images')
cases += [(str(root/(name+'.png')),'red') for name in ('974091abe71e','6a255c367822','bdcd4c0df84f')]
with open('/tmp/mm_overlap_probe.jsonl','w') as out:
 for image,color in cases:
    im=Image.open(image).convert('RGB');w,h=im.size
    boxes=[[round(c*w*.2),round(r*h*.2),round((c*.2+.4)*w),round((r*.2+.4)*h)] for r in range(4) for c in range(4)]
    msgs=[[{'role':'user','content':[im.crop(box),TILE_PROMPT]}] for box in boxes]
    start=time.monotonic()
    with torch.inference_mode():answers=model.chat(image=None,msgs=msgs,tokenizer=tokenizer,processor=processor,sampling=False,stream=False,num_beams=1,max_new_tokens=12,max_slice_nums=1)
    labels=[]
    for answer in answers:
     try:labels.append(parse_tile(answer))
     except ValueError:labels.append(None)
    positive=[b for b,label in zip(boxes,labels) if label==color]
    box=[max(b[0] for b in positive),max(b[1] for b in positive),min(b[2] for b in positive),min(b[3] for b in positive)] if positive else None
    if box and (box[0]>=box[2] or box[1]>=box[3]):box=None
    refined=refine(cv2.imread(image),box)
    result=dict(image=image,color=color,model_box=box,bbox=refined,latency_s=time.monotonic()-start,boxes=boxes,answers=answers)
    out.write(json.dumps(result)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ('boxes','answers')}),flush=True)
