import json
from pathlib import Path
import cv2
cv2.setNumThreads(2)
session=Path('/home/ubuntu/tcei_baseline_tools/results/multimodal_v2_demo2_purple_20261026')
model=session/'model/20261025T175433_c79a8a'
audit=list(map(json.loads,(model/'audit.jsonl').read_text().splitlines()))
source=next(r for r in audit if r['kind']=='model_source' and r['decision']=='a2165e42a859')
frames=[r for r in map(json.loads,(session/'audit/events.jsonl').read_text().splitlines()) if r['event']=='image' and 0<r['header_stamp']-source['stamp']<3.5]
for label,box in [('old_selected_floor',[212,334,231,353]),('graph_body',[93,299,136,340])]:
 tracker=cv2.TrackerCSRT_create();x1,y1,x2,y2=box;tracker.init(cv2.imread(str(model/source['image'])),(x1,y1,x2-x1,y2-y1))
 trace=[]
 for frame in frames:
  ok,xywh=tracker.update(cv2.imread(str(session/'audit'/frame['file'])))
  trace.append(dict(dt=frame['header_stamp']-source['stamp'],ok=bool(ok),xywh=xywh,file=frame['file']))
  if not ok:break
 print(label,json.dumps(trace),flush=True)
