import json,time
from pathlib import Path
import cv2,numpy as np
cv2.setNumThreads(2)
root=Path('/tmp/mm_graph_candidates_probe');root.mkdir(exist_ok=False)
rows=list(map(json.loads,Path('/tmp/mm_foreground_candidates_probe/results.jsonl').read_text().splitlines()))
graph=cv2.ximgproc.segmentation.createGraphSegmentation(sigma=.5,k=300,min_size=30)
with (root/'results.jsonl').open('w') as out:
 for row in rows:
  image=cv2.imread(row['source']);h,w=image.shape[:2];x1,y1,x2,y2=row['model_union']
  crop=image[y1:y2,x1:x2];start=time.monotonic();labels=graph.processImage(crop)
  candidates=[]
  for identifier in np.unique(labels):
   ys,xs=np.nonzero(labels==identifier)
   bx1,by1,bx2,by2=int(xs.min())+x1,int(ys.min())+y1,int(xs.max())+x1+1,int(ys.max())+y1+1
   if len(xs)<16 or bx2-bx1<4 or by2-by1<4:continue
   if (bx1<=x1 and x1>0) or (by1<=y1 and y1>0) or (bx2>=x2 and x2<w) or (by2>=y2 and y2<h):continue
   candidates.append(dict(region=int(identifier),bbox=[bx1,by1,bx2,by2],area=len(xs)))
  candidates.sort(key=lambda r:-r['area']);candidates=candidates[:12]
  annotated=image.copy()
  for index,candidate in enumerate(candidates):
   bx1,by1,bx2,by2=candidate['bbox'];cv2.rectangle(annotated,(bx1,by1),(bx2,by2),(0,255,0),1);cv2.putText(annotated,str(index),(bx1,by1-3),cv2.FONT_HERSHEY_SIMPLEX,.4,(0,255,255),1)
   part=image[by1:by2,bx1:bx2].copy();mask=labels[by1-y1:by2-y1,bx1-x1:bx2-x1]==candidate['region'];part[~mask]=0
   file=root/(row['decision']+'_'+str(index)+'.png');cv2.imwrite(str(file),part);candidate['image']=str(file)
  annotation=root/(row['decision']+'.jpg');cv2.imwrite(str(annotation),annotated)
  result=dict(row,candidates=candidates,annotation=str(annotation),latency_s=time.monotonic()-start)
  out.write(json.dumps(result)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='candidates'},ensure_ascii=False),'candidates',[(c['bbox'],c['area']) for c in candidates],flush=True)
