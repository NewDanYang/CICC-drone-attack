import json,sys
from pathlib import Path
import cv2,numpy as np
cv2.setNumThreads(2)
base=Path('/home/ubuntu/tcei_baseline_tools/results/multimodal_v2_demo2_purple_20261026/model/20261025T175433_c79a8a')
rows=list(map(json.loads,(base/'audit.jsonl').read_text().splitlines()))
sources={r['decision']:r for r in rows if r['kind']=='model_source'}
root=Path('/tmp/mm_foreground_candidates_probe');root.mkdir(exist_ok=False)
with (root/'results.jsonl').open('w') as out:
 for row in rows:
  if row['kind']!='overlapping_tiles':continue
  positive=[b for b,l in zip(row['boxes'],row['labels']) if l=='purple']
  if not positive:continue
  region=[min(b[0] for b in positive),min(b[1] for b in positive),max(b[2] for b in positive),max(b[3] for b in positive)]
  source=sources[row['decision']];image=str(base/source['image']);bgr=cv2.imread(image)
  h,w=bgr.shape[:2];x1,y1,x2,y2=region
  rx1,ry1=max(0,x1-64),max(0,y1-64);rx2,ry2=min(w,x2+64),min(h,y2+64)
  crop=bgr[ry1:ry2,rx1:rx2].copy();mask=np.full(crop.shape[:2],cv2.GC_BGD,np.uint8)
  mask[y1-ry1:y2-ry1,x1-rx1:x2-rx1]=cv2.GC_PR_FGD
  mask[:2,:]=mask[-2:,:]=mask[:,:2]=mask[:,-2:]=cv2.GC_BGD
  cv2.setRNGSeed(0);cv2.grabCut(crop,mask,None,np.zeros((1,65),np.float64),np.zeros((1,65),np.float64),4,cv2.GC_INIT_WITH_MASK)
  fg=np.uint8((mask==cv2.GC_FGD)|(mask==cv2.GC_PR_FGD))
  fg=cv2.morphologyEx(fg,cv2.MORPH_OPEN,cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(5,5)))
  n,labels,stats,centers=cv2.connectedComponentsWithStats(fg,8)
  boxes=[]
  for x,y,bw,bh,area in stats[1:]:
   if area<16 or bw<4 or bh<4:continue
   if (x+rx1<=x1 and x1>0) or (y+ry1<=y1 and y1>0) or (x+bw+rx1>=x2 and x2<w) or (y+bh+ry1>=y2 and y2<h):continue
   boxes.append([int(x+rx1),int(y+ry1),int(x+bw+rx1),int(y+bh+ry1)])
  annotated=bgr.copy()
  for i,b in enumerate(boxes):cv2.rectangle(annotated,b[:2],b[2:],(0,255,0),1);cv2.putText(annotated,str(i),(b[0],b[1]-3),cv2.FONT_HERSHEY_SIMPLEX,.4,(0,255,255),1)
  file=root/(row['decision']+'.jpg');cv2.imwrite(str(file),annotated)
  result=dict(source=image,decision=row['decision'],model_union=region,candidates=boxes,annotation=str(file))
  out.write(json.dumps(result)+'\n');print(json.dumps(result),flush=True)
