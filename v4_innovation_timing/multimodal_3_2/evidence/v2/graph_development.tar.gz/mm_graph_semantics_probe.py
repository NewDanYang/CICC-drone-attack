import json,sys,time,hashlib
from pathlib import Path
sys.path.insert(0,'/home/ubuntu/multimodal_v2')
from v2.localizer import semantic_labels
from PIL import Image
import torch
torch.set_num_threads(2);torch.set_num_interop_threads(1)
from transformers import AutoModel,AutoTokenizer,AutoProcessor
root=Path('/tmp/mm_graph_candidates_probe')
row=next(r for r in map(json.loads,(root/'results.jsonl').read_text().splitlines()) if r['decision']=='a2165e42a859')
path='/home/ubuntu/model/FM9G4B-V'
model=AutoModel.from_pretrained(path,trust_remote_code=True,local_files_only=True,attn_implementation='sdpa',torch_dtype=torch.bfloat16).eval().cuda()
tokenizer=AutoTokenizer.from_pretrained(path,trust_remote_code=True,local_files_only=True)
processor=AutoProcessor.from_pretrained(path,trust_remote_code=True,local_files_only=True)
with open('/tmp/mm_graph_semantics_probe.jsonl','w') as out:
 for mode in ('original_crop','region_mask'):
  source=Image.open(row['source']).convert('RGB')
  images=[source.crop(c['bbox']) if mode=='original_crop' else Image.open(c['image']).convert('RGB') for c in row['candidates']]
  evidence=[]
  def infer(images,prompt):
   start=time.monotonic()
   with torch.inference_mode():answers=model.chat(image=None,msgs=[[{'role':'user','content':[im,prompt]}] for im in images],tokenizer=tokenizer,processor=processor,sampling=False,stream=False,num_beams=1,max_new_tokens=12,max_slice_nums=1)
   evidence.append(dict(prompt=prompt,answers=answers,image_sha256=[hashlib.sha256(im.tobytes()).hexdigest() for im in images],latency_s=time.monotonic()-start))
   return answers
  labels,answers=semantic_labels(images,infer,lambda **kw:evidence.append(kw))
  result=dict(mode=mode,labels=labels,candidates=row['candidates'],evidence=evidence)
  out.write(json.dumps(result,ensure_ascii=False)+'\n');print(mode,labels,flush=True)
print('GRAPH_SEMANTICS_DONE',flush=True)
