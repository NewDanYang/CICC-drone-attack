/******************************************************************************
 * @file       visual_servo.cpp
 * @brief      Visual Servo 行为树节点 - 三阶段控制（body系 VX+VZ+yaw_rate）
 *
 * @details    三阶段：对齐(ALIGN) -> 靠近(APPROACH) -> 冲刺(SPRINT)
 *             全程使用 publishVelocityWithYawRate（body 坐标系）
 *             控制变量：VX(前进) + VZ(升降) + yaw_rate(偏航角速度)
 *
 * @author     郭定<1604289397@qq.com>
 * @date       2026-03-16
 ******************************************************************************/
#include "nodes/action/visual_servo.h"
#include "utils/pose_utils.h"
#include <algorithm>
#include <cmath>


VisualServo::VisualServo(const std::string& name, const NodeConfig& config)
    : DroneActionNode(name, config), 
      current_state_(ALIGN),
      has_ever_received_data_(false),
      max_area_ratio_(0.0) {
    auto nh = mct->getROSHandle();
    nh->param<double>("cx", img_cx_, 320.0);
    nh->param<double>("cy", img_cy_, 240.0);
    nh->param<int>("img_w", img_w_, 640);
    nh->param<int>("img_h", img_h_, 480);
}

PortsList VisualServo::providedPorts() {
    return { InputPort<PixelTarget>("pixel_target", "像素目标"),
             
             // yaw_rate PD 控制
             InputPort<double>("k_p_yaw_rate", 0.003, "偏航角速度 P 增益 (rad/s per pixel)"),
             InputPort<double>("k_d_yaw_rate", 0.008, "偏航角速度 D 增益"),
             InputPort<double>("max_yaw_rate", 0.5, "最大偏航角速度 (rad/s)"),
             InputPort<double>("deadzone_yaw", 8.0, "偏航死区 (pixel)"),
             
             // VZ PD 控制
             InputPort<double>("k_p_vz", 0.002, "垂直速度 P 增益"),
             InputPort<double>("k_d_vz", 0.006, "垂直速度 D 增益"),
             InputPort<double>("max_vz", 0.3, "最大垂直速度 (m/s)"),
             InputPort<double>("deadzone_vz", 10.0, "垂直死区 (pixel)"),
             
             // 速度参数
             InputPort<double>("forward_velocity", 0.35, "逼近阶段前进速度 (m/s)"),
             InputPort<double>("sprint_velocity", 1.5, "冲刺速度 (m/s)"),
             InputPort<double>("sprint_time", 1.2, "冲刺持续时间 (s)"),
             
             // 其他
             InputPort<double>("data_timeout", 1.0, "数据超时 (s)"),
             InputPort<double>("approach_area_threshold", 0.08, "触发冲刺的面积占比"),
             InputPort<double>("center_tolerance", 0.15, "对齐判定区域比例"),
             InputPort<double>("search_yaw_rate", 0.3, "搜索模式旋转速度 (rad/s)"),
             InputPort<std::string>("target_color", "", "当前气球颜色") };
}

NodeStatus VisualServo::onStart() {
    // 加载参数
    k_p_yaw_rate_ = getInput<double>("k_p_yaw_rate").value();
    k_d_yaw_rate_ = getInput<double>("k_d_yaw_rate").value();
    max_yaw_rate_ = getInput<double>("max_yaw_rate").value();
    deadzone_yaw_ = getInput<double>("deadzone_yaw").value();
    
    k_p_vz_ = getInput<double>("k_p_vz").value();
    k_d_vz_ = getInput<double>("k_d_vz").value();
    max_vz_ = getInput<double>("max_vz").value();
    deadzone_vz_ = getInput<double>("deadzone_vz").value();
    
    forward_velocity_ = getInput<double>("forward_velocity").value();
    sprint_velocity_ = getInput<double>("sprint_velocity").value();
    sprint_time_ = getInput<double>("sprint_time").value();
    
    data_timeout_ = getInput<double>("data_timeout").value();
    approach_area_threshold_ = getInput<double>("approach_area_threshold").value();
    center_tolerance_ = getInput<double>("center_tolerance").value();
    search_yaw_rate_ = getInput<double>("search_yaw_rate").value();
    target_color_ = getInput<std::string>("target_color").value();
    search_anchor_active_ = false;
    
    // 初始化状态机
    current_state_ = APPROACHING;  // 直接进入边飞边对齐模式（气球是移动目标）
    has_ever_received_data_ = false;
    max_area_ratio_ = 0.0;
    align_stable_frames_ = 0;
    
    // 初始化微分状态
    prev_err_x_ = 0.0;
    prev_err_y_ = 0.0;
    prev_time_ = ros::Time::now();
    
    updateTargetData();
    
    ROS_INFO("[%s]: Visual Servo Started (VX+VZ+yaw_rate)", name().c_str());
    ROS_INFO("[%s]: k_p_yaw_rate=%.4f k_d=%.4f max_rate=%.2f deadzone=%.1f", 
             name().c_str(), k_p_yaw_rate_, k_d_yaw_rate_, max_yaw_rate_, deadzone_yaw_);
    ROS_INFO("[%s]: forward_vel=%.2f sprint_vel=%.2f sprint_time=%.1f area_thresh=%.3f",
             name().c_str(), forward_velocity_, sprint_velocity_, sprint_time_, approach_area_threshold_);
    
    return NodeStatus::RUNNING;
}

NodeStatus VisualServo::onRunning() {
    updateTargetData();
    
    // 计算时间步长
    ros::Time now = ros::Time::now();
    double dt = (now - prev_time_).toSec();
    if (dt < 0.001) dt = 0.001;
    
    // 目标丢失处理（冲刺阶段不检查）
    if (current_state_ != SPRINTING && isTargetLost()) {
        // A blue balloon can pop while ALIGN is still active. The old 50 s
        // position-held search stays in the nearby red balloon's travel lane.
        // Finish only when the last blue detection was near and then vanished.
        const double last_ratio = last_target_.area() /
            (static_cast<double>(img_w_) * img_h_);
        const double lost_seconds = (now - last_valid_detection_time_).toSec();
        if (target_color_ == "blue" && has_ever_received_data_) {
            ROS_INFO_THROTTLE(1.0, "[%s]: BLUE_LOSS_SAMPLE area=%.4f max_area=%.4f lost_s=%.3f",
                              name().c_str(), last_ratio, max_area_ratio_, lost_seconds);
        }
        if (target_color_ == "blue" && has_ever_received_data_ &&
            max_area_ratio_ >= 0.30 &&
            last_ratio >= 0.50 * approach_area_threshold_ &&
            lost_seconds <= data_timeout_ + 0.25) {
            sendHoverCommand();
            ROS_INFO("[%s]: BLUE_NEAR_CONTACT_LOSS_COMPLETE area=%.4f max_area=%.4f lost_s=%.3f",
                     name().c_str(), last_ratio, max_area_ratio_, lost_seconds);
            return NodeStatus::SUCCESS;
        }
        if (current_state_ != ALIGN) {
            current_state_ = ALIGN;
            align_stable_frames_ = 0;
            ROS_WARN("[%s]: Off-center target lost after approach; return to ALIGN and search.",
                     name().c_str());
        }
        // Body-frame zero velocity drifted 2.5 m during a 50-second
        // purple search. Keep the current world position while scanning yaw.
        if (!search_anchor_active_) {
            search_anchor_ = fcu_odom_ptr->pose.pose.position;
            search_base_yaw_ = PoseUtils::getYawFromQuat(fcu_odom_ptr->pose.pose.orientation);
            search_start_time_ = now;
            search_anchor_active_ = true;
            ROS_INFO("[%s]: SEARCH_ANCHOR pos=(%.3f,%.3f,%.3f) yaw=%.3f",
                     name().c_str(), search_anchor_.x, search_anchor_.y,
                     search_anchor_.z, search_base_yaw_);
        }
        const double search_yaw = search_base_yaw_ +
            search_yaw_rate_ * (now - search_start_time_).toSec();
        publishPosition(search_anchor_, search_yaw);
        ROS_WARN_THROTTLE(1.0, "[%s]: Target lost. Position-held search yaw=%.3f anchor=(%.2f,%.2f,%.2f)",
                          name().c_str(), search_yaw, search_anchor_.x,
                          search_anchor_.y, search_anchor_.z);
        return NodeStatus::RUNNING;
    }
    search_anchor_active_ = false;
    
    // 计算基本量
    double img_area = static_cast<double>(img_w_) * img_h_;
    double current_ratio = last_target_.area() / img_area;
    double err_x = last_target_.center_x - img_cx_;  // 正=目标在右侧
    double err_y = last_target_.center_y - img_cy_;  // 正=目标在下方
    
    // 更新最大面积记录
    if (current_ratio > max_area_ratio_) {
        max_area_ratio_ = current_ratio;
    }
    
    // PD 控制计算
    double yaw_rate = computeYawRate(err_x, dt);
    double vz = computeVz(err_y, dt);
    
    // 更新微分状态
    prev_time_ = now;
    
    // =========== 三阶段状态机 ===========
    switch (current_state_) {
        case ALIGN: {
            // 阶段1：对齐 — 原地旋转 + 升降，使目标居中
            publishVelocityWithYawRate(0, 0, vz, yaw_rate);
            
            if (isCentered()) {
                align_stable_frames_++;
                if (align_stable_frames_ >= ALIGN_STABLE_FRAMES_REQUIRED) {
                    current_state_ = APPROACHING;
                    align_stable_frames_ = 0;
                    ROS_INFO("[%s]: Aligned! err:(%.0f,%.0f) -> APPROACHING", 
                             name().c_str(), err_x, err_y);
                }
            } else {
                align_stable_frames_ = 0;
            }
            
            ROS_INFO_THROTTLE(1.0, "[%s]: ALIGN - err:(%.0f,%.0f) yaw_rate:%.3f vz:%.3f stable:%d", 
                             name().c_str(), err_x, err_y, yaw_rate, vz, align_stable_frames_);
            break;
        }
        
        case APPROACHING: {
            // 阶段2：靠近 — VX 前进 + yaw_rate + VZ，全程持续修正
            // 根据对齐程度调节前进速度（越偏越慢）
            double align_ratio = std::max(0.0, 1.0 - std::abs(err_x) / (img_w_ * 0.3));
            double vx = forward_velocity_ * align_ratio;
            // Close range with an off-center target needs yaw/vz correction,
            // not more forward travel that drives the target out of frame.
            if (current_ratio >= approach_area_threshold_ && !isCentered()) {
                vx = 0.0;
            }
            // Red successes entered the sprint near yaw +/-pi; an observed
            // yaw=2.251 sprint ran toward the boundary and removed blue.
            bool red_heading_blocked = false;
            if (target_color_ == "red" && current_ratio >= approach_area_threshold_) {
                const double yaw = PoseUtils::getYawFromQuat(fcu_odom_ptr->pose.pose.orientation);
                const double yaw_error = std::abs(std::atan2(std::sin(yaw - M_PI), std::cos(yaw - M_PI)));
                red_heading_blocked = yaw_error > 0.45;
                if (red_heading_blocked) {
                    vx = 0.0;
                    ROS_WARN_THROTTLE(0.5, "[%s]: Red sprint heading blocked: yaw=%.3f error=%.3f rad",
                                      name().c_str(), yaw, yaw_error);
                }
            }
            
            publishVelocityWithYawRate(vx, 0, vz, yaw_rate);
            
            // 对齐偏差过大 → 回到 ALIGN
            if (std::abs(err_x) > img_w_ * center_tolerance_ * 3) {
                current_state_ = ALIGN;
                align_stable_frames_ = 0;
                ROS_WARN("[%s]: Alignment lost (err_x=%.0f), back to ALIGN", 
                         name().c_str(), err_x);
                break;
            }
            
            // 面积达阈值 → 触发冲刺
            if (current_ratio >= approach_area_threshold_ && isCentered() && !red_heading_blocked) {
                current_state_ = SPRINTING;
                sprint_start_time_ = ros::Time::now();
                const auto& sprint_pose = fcu_odom_ptr->pose.pose;
                ROS_INFO("[%s]: SPRINT_START pos=(%.3f,%.3f,%.3f) yaw=%.3f err=(%.1f,%.1f) area=%.4f velocity=%.3f time=%.3f",
                         name().c_str(), sprint_pose.position.x, sprint_pose.position.y,
                         sprint_pose.position.z, PoseUtils::getYawFromQuat(sprint_pose.orientation),
                         err_x, err_y, current_ratio, sprint_velocity_, sprint_time_);
                ROS_INFO("[%s]: Area %.1f%% >= %.1f%% -> SPRINT! (sprint_vel=%.2f, time=%.1fs)", 
                         name().c_str(), current_ratio*100, approach_area_threshold_*100,
                         sprint_velocity_, sprint_time_);
            } else if (current_ratio >= approach_area_threshold_) {
                ROS_WARN_THROTTLE(0.5, "[%s]: Sprint area ready but off-center err:(%.0f,%.0f); continue alignment",
                                  name().c_str(), err_x, err_y);
            }
            
            ROS_INFO_THROTTLE(0.5, "[%s]: APPROACH - vx:%.2f(%.0f%%) yaw_rate:%.3f vz:%.3f err:(%.0f,%.0f) area:%.1f%%", 
                             name().c_str(), vx, align_ratio*100, yaw_rate, vz, 
                             err_x, err_y, current_ratio*100);
            break;
        }
        
        case SPRINTING: {
            // 阶段3：冲刺 — 全速前进，保持 yaw_rate 和 VZ 修正
            double sprint_dt = (ros::Time::now() - sprint_start_time_).toSec();
            
            // 超时 → 完成
            if (sprint_dt >= sprint_time_) {
                const auto& sprint_pose = fcu_odom_ptr->pose.pose;
                ROS_INFO("[%s]: SPRINT_END pos=(%.3f,%.3f,%.3f) yaw=%.3f err=(%.1f,%.1f) area=%.4f target_fresh=%d velocity=%.3f time=%.3f",
                         name().c_str(), sprint_pose.position.x, sprint_pose.position.y,
                         sprint_pose.position.z, PoseUtils::getYawFromQuat(sprint_pose.orientation),
                         err_x, err_y, current_ratio, !isTargetLost(), sprint_velocity_, sprint_time_);
                // A visible, far-off-center blue balloon is direct evidence
                // that the fixed-time sprint missed. Stop and realign rather
                // than reporting a hit and flying the landing return route.
                if (target_color_ == "blue" && !isTargetLost() &&
                    current_ratio >= 0.03 && std::abs(err_x) > 0.20 * img_w_) {
                    sendHoverCommand();
                    current_state_ = ALIGN;
                    align_stable_frames_ = 0;
                    ROS_WARN("[%s]: BLUE_SPRINT_VISIBLE_RETRY err_x=%.1f area=%.4f",
                             name().c_str(), err_x, current_ratio);
                    break;
                }
                sendHoverCommand();
                ROS_INFO("[%s]: Sprint completed (%.1fs). SUCCESS.", name().c_str(), sprint_dt);
                return NodeStatus::SUCCESS;
            }
            
            // 冲刺中仍然持续修正 yaw_rate 和 vz（如果还看得到目标）
            if (!isTargetLost()) {
                publishVelocityWithYawRate(sprint_velocity_, 0, vz, yaw_rate);
            } else {
                // 目标丢失，保持直线冲刺
                publishVelocityWithYawRate(sprint_velocity_, 0, 0, 0);
            }
            
            ROS_INFO_THROTTLE(0.2, "[%s]: SPRINT - vx:%.2f yaw_rate:%.3f vz:%.3f (%.1f/%.1fs)", 
                             name().c_str(), sprint_velocity_, yaw_rate, vz,
                             sprint_dt, sprint_time_);
            break;
        }
    }
    
    return NodeStatus::RUNNING;
}

// =====================================================================
// PD 控制器
// =====================================================================

double VisualServo::computeYawRate(double err_x, double dt) {
    // 目标在右侧(err_x>0) → 需要右转 → yaw_rate < 0 (NED 逆时针为正)
    double err = err_x;
    
    // 死区
    double err_after_dz = 0.0;
    if (std::abs(err) > deadzone_yaw_) {
        err_after_dz = err - std::copysign(deadzone_yaw_, err);
    }
    
    // PD
    double d_err = (dt > 1e-6) ? (err_after_dz - prev_err_x_) / dt : 0.0;
    double yaw_rate = -(k_p_yaw_rate_ * err_after_dz + k_d_yaw_rate_ * d_err);
    
    // 限幅
    yaw_rate = std::clamp(yaw_rate, -max_yaw_rate_, max_yaw_rate_);
    
    prev_err_x_ = err_after_dz;
    return yaw_rate;
}

double VisualServo::computeVz(double err_y, double dt) {
    // 目标在下方(err_y>0) → 需要下降 → vz < 0 (看飞控坐标系)
    double err = err_y;
    
    // 死区
    double err_after_dz = 0.0;
    if (std::abs(err) > deadzone_vz_) {
        err_after_dz = err - std::copysign(deadzone_vz_, err);
    }
    
    // PD
    double d_err = (dt > 1e-6) ? (err_after_dz - prev_err_y_) / dt : 0.0;
    double vz = -(k_p_vz_ * err_after_dz + k_d_vz_ * d_err);
    
    // 限幅
    vz = std::clamp(vz, -max_vz_, max_vz_);
    
    prev_err_y_ = err_after_dz;
    return vz;
}

// =====================================================================
// 辅助函数
// =====================================================================

void VisualServo::updateTargetData() {
    auto target_res = getInput<PixelTarget>("pixel_target");
    if (!target_res) return;

    PixelTarget current_target = target_res.value();
    if (current_target.is_detected) {
        last_target_ = current_target;
        last_valid_detection_time_ = ros::Time::now(); 
        has_ever_received_data_ = true;
        
        double img_area = static_cast<double>(img_w_) * img_h_;
        double ratio = last_target_.area() / img_area;
        if (ratio > max_area_ratio_) {
            max_area_ratio_ = ratio;
        }
    }
}

bool VisualServo::isTargetLost() {
    if (!has_ever_received_data_) return true;
    return (ros::Time::now() - last_valid_detection_time_).toSec() > data_timeout_;
}

bool VisualServo::isCentered() const {
    double err_x = last_target_.center_x - img_cx_;
    double err_y = last_target_.center_y - img_cy_;
    // A controller cannot reduce error inside its own zero-command deadzone.
    // Accept that region as centered even when the target box is very small.
    double tol_w = std::max(last_target_.width * center_tolerance_, deadzone_yaw_);
    double tol_h = std::max(last_target_.height * center_tolerance_, deadzone_vz_);
    return std::abs(err_x) <= tol_w && std::abs(err_y) <= tol_h;
}

BT_REGISTER_NODES(factory) {
    factory.registerNodeType<VisualServo>("VisualServo");
}
